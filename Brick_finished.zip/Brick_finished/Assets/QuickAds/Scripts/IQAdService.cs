﻿
namespace QAds
{
    public interface IQAdService
    {
        void InitializeAdService();
    }
}
